Aeron


Moves:

 D>A - Double Palm
 D>J - Tornado

~by Siegvar[Sprites] and YinYin[Data]
~www.y-2-f.tk


Installation:
- Move the sprite-folder and the data-folder into your LF2-directory
- Add these lines to data.txt (to the object-part):

 id:    38  type: 0  file: data\aeron.dat
 id:  2000  type: 1  file: data\aeron_ww.dat

- Have fun playing!

______________________________________________________________________

                           www.lf-empire.de

                      Little Fighter EMPIRE v8.0
                           ~ all you need ~