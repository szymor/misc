Silva

~by Jan Leuschner aka YinYin Falcon


Installation:
- Move all folders into your LF2-directory
- Add these lines to data.txt (to the object-part):

 id: 240  type: 3  file: data\silva_exp.dat
 id: 241  type: 4  file: data\silva_weap.dat

-Submit one of these lines to data.txt for AI:

 id:   3  type: 0  file: data\silva.dat      #no AI
 id:  10  type: 0  file: data\silva.dat      #woody's AI
 id:  11  type: 0  file: data\silva.dat      #davis' AI

- Have fun playing!


I'm giving you the option of having a good artificial intelligence
for Silva (using second or third line) and messing up rudolfs
transformation regarding Silva and the character's AI you use,
or using no AI for him and not affecting other characters.
So you may choose one of the three lines. The id: 3 can be
replaced with any other id that is not in use.

______________________________________________________________________

                           www.lf-empire.de

                      Little Fighter EMPIRE v8.0
                           ~ all you need ~